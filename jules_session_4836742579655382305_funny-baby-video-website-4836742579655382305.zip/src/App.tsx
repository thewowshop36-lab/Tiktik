import { useState, useMemo, useEffect } from 'react';
import { MOCK_VIDEOS } from './data/videos';
import type { Video } from './data/videos';
import { Navbar } from './components/Navbar';
import { HeroBanner } from './components/HeroBanner';
import { CategoryFilter } from './components/CategoryFilter';
import { VideoCard } from './components/VideoCard';
import { VideoModal } from './components/VideoModal';
import { SubmitVideoModal } from './components/SubmitVideoModal';
import { Soundboard } from './components/Soundboard';
import { LaughChallenge } from './components/LaughChallenge';
import { MemeGenerator } from './components/MemeGenerator';
import { Footer } from './components/Footer';
import { Laugh, Sparkles, AlertCircle } from 'lucide-react';

export function App() {
  const [videos, setVideos] = useState<Video[]>(MOCK_VIDEOS);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [activeTab, setActiveTab] = useState<'videos' | 'challenge' | 'memes' | 'soundboard'>('videos');
  const [selectedVideo, setSelectedVideo] = useState<Video | null>(null);
  const [isSubmitModalOpen, setIsSubmitModalOpen] = useState(false);
  const [darkMode, setDarkMode] = useState(false);
  const [isHindi, setIsHindi] = useState(true);

  // Sync Dark mode HTML class
  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [darkMode]);

  // Handle Video Likes
  const handleLikeVideo = (id: string) => {
    setVideos((prev) =>
      prev.map((v) => (v.id === id ? { ...v, likes: v.likes + 1 } : v))
    );
    if (selectedVideo && selectedVideo.id === id) {
      setSelectedVideo((prev) => (prev ? { ...prev, likes: prev.likes + 1 } : null));
    }
  };

  // Handle Video Laughs
  const handleLaughVideo = (id: string) => {
    setVideos((prev) =>
      prev.map((v) => (v.id === id ? { ...v, laughsCount: v.laughsCount + 1 } : v))
    );
    if (selectedVideo && selectedVideo.id === id) {
      setSelectedVideo((prev) => (prev ? { ...prev, laughsCount: prev.laughsCount + 1 } : null));
    }
  };

  // Handle Adding Comment
  const handleAddComment = (videoId: string, commentText: string) => {
    const newCommentObj = {
      id: `c_${Date.now()}`,
      user: commentText.split(':')[0] || 'User',
      avatar: '👶',
      text: commentText.split(':')[1] || commentText,
      timeAgo: 'Just now',
      likes: 1,
    };

    setVideos((prev) =>
      prev.map((v) =>
        v.id === videoId ? { ...v, comments: [newCommentObj, ...v.comments] } : v
      )
    );

    if (selectedVideo && selectedVideo.id === videoId) {
      setSelectedVideo((prev) =>
        prev ? { ...prev, comments: [newCommentObj, ...prev.comments] } : null
      );
    }
  };

  // Handle Submitting New Video
  const handleUserSubmitVideo = (data: { title: string; category: string; videoUrl: string; description: string }) => {
    const newVideo: Video = {
      id: `v_${Date.now()}`,
      title: data.title,
      hindiTitle: `${data.title} 👶✨`,
      description: data.description,
      category: data.category as Video['category'],
      videoUrl: data.videoUrl,
      thumbnailUrl: 'https://images.unsplash.com/photo-1519689680058-324335c77eba?auto=format&fit=crop&w=800&q=80',
      duration: '1:00',
      views: 1,
      likes: 5,
      laughsCount: 12,
      uploadedAgo: 'Just now',
      tags: ['baby', 'funny', 'new'],
      comments: [
        { id: 'c_init', user: 'Community', avatar: '🥳', text: 'Welcome new baby video!', timeAgo: 'Just now', likes: 1 }
      ]
    };

    setVideos((prev) => [newVideo, ...prev]);
  };

  // Filter Videos according to Category & Search Query
  const filteredVideos = useMemo(() => {
    return videos.filter((video) => {
      const matchesCategory = selectedCategory === 'All' || video.category === selectedCategory;
      const query = searchQuery.toLowerCase().trim();
      const matchesSearch =
        !query ||
        video.title.toLowerCase().includes(query) ||
        video.hindiTitle.toLowerCase().includes(query) ||
        video.description.toLowerCase().includes(query) ||
        video.tags.some((tag) => tag.toLowerCase().includes(query));

      return matchesCategory && matchesSearch;
    });
  }, [videos, selectedCategory, searchQuery]);

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 transition-colors font-sans flex flex-col">
      {/* Top Navbar */}
      <Navbar
        searchQuery={searchQuery}
        setSearchQuery={setSearchQuery}
        darkMode={darkMode}
        setDarkMode={setDarkMode}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onOpenSubmitModal={() => setIsSubmitModalOpen(true)}
        isHindi={isHindi}
        setIsHindi={setIsHindi}
      />

      {/* Main Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        
        {/* Banner Hero */}
        <HeroBanner
          isHindi={isHindi}
          onExploreClick={() => {
            setActiveTab('videos');
            window.scrollTo({ top: 400, behavior: 'smooth' });
          }}
          onPlayGameClick={() => {
            setActiveTab('challenge');
            window.scrollTo({ top: 200, behavior: 'smooth' });
          }}
        />

        {/* Tab View Conditionals */}
        {activeTab === 'soundboard' && (
          <Soundboard isHindi={isHindi} />
        )}

        {activeTab === 'challenge' && (
          <LaughChallenge videos={videos} isHindi={isHindi} />
        )}

        {activeTab === 'memes' && (
          <MemeGenerator isHindi={isHindi} />
        )}

        {/* Video Hub Section (Default) */}
        <div className="space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-xl bg-pink-100 dark:bg-pink-950 text-pink-600 flex items-center justify-center font-black">
                <Laugh className="w-5 h-5" />
              </div>
              <h2 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-slate-100">
                {isHindi ? 'मजेदार वीडियोस गिल्ड' : 'Trending Baby Videos'}
              </h2>
            </div>

            <span className="text-xs font-bold text-slate-500 dark:text-slate-400 bg-slate-200/60 dark:bg-slate-800 px-3 py-1.5 rounded-full w-fit">
              {filteredVideos.length} {isHindi ? 'वीडियोस मिले' : 'Clips Found'}
            </span>
          </div>

          {/* Category Pills Filter */}
          <CategoryFilter
            selectedCategory={selectedCategory}
            onSelectCategory={setSelectedCategory}
            isHindi={isHindi}
          />

          {/* Videos Grid */}
          {filteredVideos.length === 0 ? (
            <div className="text-center py-16 bg-white dark:bg-slate-900 rounded-3xl border border-dashed border-slate-300 dark:border-slate-800 p-8">
              <AlertCircle className="w-12 h-12 text-pink-400 mx-auto mb-3 animate-bounce" />
              <h3 className="text-lg font-bold mb-1">
                {isHindi ? 'कोई वीडियो नहीं मिला!' : 'No funny clips found'}
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400 mb-4">
                {isHindi
                  ? 'कृपया दूसरा सर्च शब्द या श्रेणी चुनें।'
                  : 'Try adjusting your search query or selecting another category.'}
              </p>
              <button
                onClick={() => {
                  setSearchQuery('');
                  setSelectedCategory('All');
                }}
                className="px-4 py-2 bg-pink-500 text-white rounded-xl font-bold text-xs hover:bg-pink-600 transition"
              >
                {isHindi ? 'सभी वीडियोस देखें' : 'Reset Filters'}
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredVideos.map((video) => (
                <VideoCard
                  key={video.id}
                  video={video}
                  onSelectVideo={setSelectedVideo}
                  isHindi={isHindi}
                  onLikeVideo={handleLikeVideo}
                  onLaughVideo={handleLaughVideo}
                />
              ))}
            </div>
          )}
        </div>

        {/* Quick Floating Soundboard Preview Banner */}
        {activeTab !== 'soundboard' && (
          <div className="mt-12 p-6 rounded-3xl bg-gradient-to-r from-purple-600 via-pink-600 to-rose-500 text-white flex flex-col sm:flex-row items-center justify-between gap-4 shadow-xl">
            <div className="flex items-center gap-3">
              <span className="text-4xl">🔊</span>
              <div>
                <h3 className="font-black text-lg">
                  {isHindi ? 'बेबी साउंड इफेक्ट्स बजाएं!' : 'Instant Baby Sound Effects!'}
                </h3>
                <p className="text-xs text-purple-100">
                  {isHindi ? 'बच्चों की खिलखिलाहट, छींक और क्यूट आवाजें सुनें' : 'Play live giggles, sneezes, and cute babble sounds'}
                </p>
              </div>
            </div>
            <button
              onClick={() => setActiveTab('soundboard')}
              className="px-5 py-2.5 rounded-xl bg-white text-purple-700 font-extrabold text-xs sm:text-sm hover:bg-purple-50 transition shadow-md whitespace-nowrap flex items-center gap-1.5"
            >
              <Sparkles className="w-4 h-4 text-purple-600" />
              {isHindi ? 'साउंड बोर्ड खोलें' : 'Open Soundboard'}
            </button>
          </div>
        )}

      </main>

      {/* Video Modal Player */}
      <VideoModal
        video={selectedVideo}
        onClose={() => setSelectedVideo(null)}
        isHindi={isHindi}
        onLikeVideo={handleLikeVideo}
        onLaughVideo={handleLaughVideo}
        onAddComment={handleAddComment}
      />

      {/* Submit Video Modal */}
      <SubmitVideoModal
        isOpen={isSubmitModalOpen}
        onClose={() => setIsSubmitModalOpen(false)}
        isHindi={isHindi}
        onSubmit={handleUserSubmitVideo}
      />

      {/* Footer */}
      <Footer isHindi={isHindi} />
    </div>
  );
}

export default App;
